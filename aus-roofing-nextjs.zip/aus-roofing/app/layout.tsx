import type { Metadata } from 'next';
import './globals.css';
import {Header,Footer} from '@/components/site';
export const metadata: Metadata = {title:{default:'AUS Roofing | Roof Repairs & Restoration',template:'%s | AUS Roofing'},description:'Roof repairs, roof restoration, gutter replacement and inspections across South East Queensland. Request a free, no-obligation quote.'};
export default function RootLayout({children}:{children:React.ReactNode}){return <html lang="en-AU"><body><Header/><main>{children}</main><Footer/></body></html>}
