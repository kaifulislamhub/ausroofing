import type { Config } from 'tailwindcss';
const config: Config = { content: ['./app/**/*.{js,ts,jsx,tsx,mdx}','./components/**/*.{js,ts,jsx,tsx,mdx}'], theme: { extend: { colors: { navy: '#0B1F44', 'navy-dark': '#081631', orange: '#F26A1B', 'orange-hover': '#D95A10', mist: '#F4F6FA' }, fontFamily: { heading: ['Arial Narrow','Arial','sans-serif'], sans: ['Arial','Helvetica','sans-serif'] }, boxShadow: { card: '0 4px 16px rgba(11,31,68,.08)' } } }, plugins: [] };
export default config;
