# AUS Roofing — Next.js website starter

Responsive multi-page website based on the supplied AUS Roofing specification. Built with Next.js App Router, TypeScript, Tailwind CSS and Lucide icons.

## Run locally

Requirements: Node.js 18.17+ (Node 20 LTS recommended).

```bash
npm install
npm run dev
```

Open http://localhost:3000.

Production build:

```bash
npm run build
npm start
```

## Pages included

- `/` Home
- `/services` Services overview
- `/services/[slug]` 10 service detail pages
- `/about-us` About Us
- `/reviews` Reviews placeholder / verified review integration point
- `/service-areas` Service area overview
- `/service-areas/[slug]` 6 regional landing pages
- `/roof-guides` Guide listing with category filtering and search
- `/roof-guides/[slug]` 6 guide article pages
- `/contact` Contact and quote form
- `/privacy` Privacy policy starter
- `/terms` Terms starter

## Before production launch

1. Replace `hello@ausroofing.example` with the real business email.
2. Verify the phone number, review count/rating, licence and insurance claims, warranty terms, and service-area coverage.
3. Replace review placeholders with genuine approved reviews and connect the correct Google Business Profile.
4. Replace placeholder/stock images with properly licensed brand photography. Images currently load from Unsplash URLs.
5. The quote form currently opens a prefilled email using `mailto:`. Connect a secure form endpoint, CRM, or booking provider for reliable production submissions; do not treat the client-side mailto interaction as a stored submission.
6. Replace the privacy and terms starter copy with reviewed legal content appropriate to the business and Australian privacy requirements.
7. Confirm accessibility, structured data, performance and mobile behavior against real content before launch.

## Design system

Core tokens are defined in `app/globals.css` and `tailwind.config.ts`: navy `#0B1F44`, deep navy `#081631`, orange `#F26A1B`, hover orange `#D95A10`, and mist `#F4F6FA`. Shared header, footer, forms, service cards, trust bar, CTA, FAQ and process blocks are in `components/site.tsx`.
